from distutils.core import setup

setup(
    name='PostCode',
    version='0.1dev',
    packages=[],
    url=''
)
